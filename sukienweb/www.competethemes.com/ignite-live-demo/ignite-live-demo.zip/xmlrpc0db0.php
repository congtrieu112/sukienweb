<?xml version="1.0" encoding="UTF-8"?><rsd version="1.0" xmlns="http://archipelago.phrasewise.com/rsd">
  <service>
    <engineName>WordPress</engineName>
    <engineLink>http://wordpress.org/</engineLink>
    <homePageLink>https://www.competethemes.com/ignite-live-demo</homePageLink>
    <apis>
      <api name="WordPress" blogID="1" preferred="true" apiLink="https://www.competethemes.com/ignite-live-demo/xmlrpc.php" />
      <api name="Movable Type" blogID="1" preferred="false" apiLink="https://www.competethemes.com/ignite-live-demo/xmlrpc.php" />
      <api name="MetaWeblog" blogID="1" preferred="false" apiLink="https://www.competethemes.com/ignite-live-demo/xmlrpc.php" />
      <api name="Blogger" blogID="1" preferred="false" apiLink="https://www.competethemes.com/ignite-live-demo/xmlrpc.php" />
          </apis>
  </service>
</rsd>
